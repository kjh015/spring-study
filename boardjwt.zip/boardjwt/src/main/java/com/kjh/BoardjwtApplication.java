package com.kjh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardjwtApplication.class, args);
	}

}
