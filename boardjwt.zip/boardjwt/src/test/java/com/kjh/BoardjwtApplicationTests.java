package com.kjh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardjwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
